NovaMart Lab v1.1 - Splunk Fundamentals Day 1 + Day 2 (StackMaster Tech)
=========================================================================

Install:  Apps > Manage Apps > Install app from file > novamart_lab.tgz > Upload > Restart Splunk.

What it does
- Creates index "novamart".
- Reads the bundled log files once (data/ folder) into index novamart:
    web01, web02   access_combined     10,856 + 11,785 events
    app01          novamart:app         3,042 events
    paygw01        novamart:payment       806 events
    bastion01      linux_secure         1,082 events (TZ = Asia/Kolkata)
- Defines source types novamart:app, novamart:payment and novamart:firewall.
- Adds lookups novamart_products, http_status and threat_intel_ips (shared globally).
- Adds the "NovaMart Lab Overview" dashboard.
- Optional: a UDP 5514 input (disabled) for the firewall replay script in data/network/.

New in 1.1 (Day 2)
- data/live/novamart_live.py writes LIVE events (current time) that are monitored automatically:
    web_live_access.log -> access_combined (host web03), app_live.log -> novamart:app (host app01),
    secure_live.log -> linux_secure (host bastion01).
  Run:  python3 $SPLUNK_HOME/etc/apps/novamart_lab/data/live/novamart_live.py --mode normal --minutes 120 &
  Modes: normal | incident | bruteforce (combine several).
- data/tools/webhook_listener.py - local receiver for the webhook alert action (port 8765).
- data/troubleshoot/ - the broken inventory feed for the Lab 14 ingestion-troubleshooting exercise
  (NOT monitored by this app on purpose).

Upgrading from 1.0: Install app from file and tick "Upgrade app". Existing data is not re-indexed.

Search with the time range picker set to All time (the data covers 14-20 Sep 2026 IST).
Do not also upload the same files manually, or every event will be indexed twice.
For Splunk Enterprise (single instance). Splunk Cloud does not allow apps to monitor bundled files.

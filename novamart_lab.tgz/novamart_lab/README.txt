NovaMart Lab - Splunk Fundamentals Day 1 (StackMaster Tech)
===========================================================

Install:  Apps > Manage Apps > Install app from file > novamart_lab.tgz > Upload > Restart Splunk.

What it does
- Creates index "novamart".
- Reads the bundled log files once (data/ folder) into index novamart:
    web01, web02   access_combined     10,856 + 11,785 events
    app01          novamart:app         3,042 events
    paygw01        novamart:payment       806 events
    bastion01      linux_secure         1,082 events (TZ = Asia/Kolkata)
- Defines source types novamart:app, novamart:payment and novamart:firewall.
- Adds lookups novamart_products, http_status and threat_intel_ips (shared globally).
- Adds the "NovaMart Lab Overview" dashboard.
- Optional: a UDP 5514 input (disabled) for the firewall replay script in data/network/.

Search with the time range picker set to All time (the data covers 14-20 Sep 2026 IST).
Do not also upload the same files manually, or every event will be indexed twice.
For Splunk Enterprise (single instance). Splunk Cloud does not allow apps to monitor bundled files.

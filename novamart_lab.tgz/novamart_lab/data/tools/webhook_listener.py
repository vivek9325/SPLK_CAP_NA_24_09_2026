#!/usr/bin/env python3
"""
Tiny webhook receiver for the Splunk alert lab (Lab 13).

Run it on the Splunk server:      python3 webhook_listener.py            (listens on port 8765)
Point the Splunk Webhook alert action at:   http://127.0.0.1:8765/novamart-alert

Every POST that Splunk sends is printed to the screen and appended to
webhook_received.log (next to this script). Standard library only. Stop with Ctrl+C.
"""
import json, os, sys
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "webhook_received.log")


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", 0) or 0)).decode("utf-8", "replace")
        try:
            data = json.loads(body)
            pretty = json.dumps(data, indent=2)
            summary = f"search_name={data.get('search_name')}  result={json.dumps(data.get('result'))[:200]}"
        except ValueError:
            pretty, summary = body, "(non-JSON payload)"
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n=== {stamp}  POST {self.path}  ===\n{summary}\n{pretty}", flush=True)
        with open(LOG, "a") as f:
            f.write(f"=== {stamp} POST {self.path}\n{pretty}\n")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"status":"received"}')

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    print(f"NovaMart webhook listener on http://0.0.0.0:{PORT}  (log: {LOG})  Ctrl+C to stop", flush=True)
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()

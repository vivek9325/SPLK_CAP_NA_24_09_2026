#!/usr/bin/env python3
"""
NovaMart LIVE traffic generator  (Splunk Day 2 labs: dashboards and alerts)

Writes events stamped with the CURRENT time into three log files in the
output folder (default: the folder this script is in):

    web_live_access.log   Apache combined   -> sourcetype access_combined, host web03
    app_live.log          NovaMart app log  -> sourcetype novamart:app,    host app01
    secure_live.log       Linux secure log  -> sourcetype linux_secure,    host bastion01

Modes (combine several):
    normal      steady shopper traffic, successful checkouts, admin SSH logins
    incident    payment gateway gw-beta times out -> HTTP 503 on /checkout + app ERRORs
    bruteforce  SSH password guessing against bastion01 from 203.0.113.99

Examples:
    python3 novamart_live.py                                  # normal traffic for 30 minutes
    python3 novamart_live.py --mode normal --minutes 120 &    # background traffic for 2 hours
    python3 novamart_live.py --mode incident --minutes 6      # trigger the checkout alert
    python3 novamart_live.py --mode bruteforce --minutes 3    # trigger the brute-force alert
    python3 novamart_live.py --mode normal incident --minutes 10

Only the Python 3 standard library is used. Stop with Ctrl+C.
"""
import argparse, os, random, sys, time
from datetime import datetime, timedelta, timezone

# The bastion syslog has no time zone in its text. Like the Day 1 secure.log it is written in IST,
# and Splunk is told TZ = Asia/Kolkata for it, so it is parsed correctly on a server in any time zone.
IST = timezone(timedelta(hours=5, minutes=30))

PRODUCTS = {"NM-1001": 18999, "NM-1002": 2499, "NM-1003": 1799, "NM-1004": 27999, "NM-1005": 4999,
            "NM-2001": 1499, "NM-2002": 1899, "NM-2003": 2999, "NM-3002": 5999, "NM-3004": 599,
            "NM-4001": 899, "NM-5001": 1299, "NM-6001": 349, "NM-6002": 799}
CATS = {"NM-1": "ELECTRONICS", "NM-2": "FASHION", "NM-3": "HOME_KITCHEN", "NM-4": "BOOKS", "NM-5": "SPORTS", "NM-6": "BEAUTY"}
UAS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
       "Mozilla/5.0 (Linux; Android 14; SM-A546E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36",
       "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",
       "NovaMartApp/4.2.1 (Android 14; build 421)", "NovaMartApp/4.2.1 (iOS 17.6; build 421)"]
REGIONS = ["North", "South", "East", "West"]
ADMINS = [("deploy", "10.20.1.15"), ("devops", "10.20.1.22"), ("ananya", "10.20.1.31")]
BF_USERS = ["root", "admin", "test", "oracle", "ubuntu", "postgres", "guest", "deploy"]


def rip():
    return f"{random.choice([49, 103, 106, 117, 157, 223])}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"


class Live:
    def __init__(self, outdir):
        os.makedirs(outdir, exist_ok=True)
        self.web = open(os.path.join(outdir, "web_live_access.log"), "a", buffering=1)
        self.app = open(os.path.join(outdir, "app_live.log"), "a", buffering=1)
        self.sec = open(os.path.join(outdir, "secure_live.log"), "a", buffering=1)
        self.order = random.randint(700000, 799999)
        self.txn = random.randint(500000, 599999)
        self.pid = random.randint(30000, 40000)
        self.counts = {"web": 0, "app": 0, "secure": 0}

    @staticmethod
    def now():
        return datetime.now().astimezone()

    def w_web(self, ip, method, uri, status, size, ua, ref="-"):
        ts = self.now().strftime("%d/%b/%Y:%H:%M:%S %z")
        self.web.write(f'{ip} - - [{ts}] "{method} {uri} HTTP/1.1" {status} {size} "{ref}" "{ua}"\n')
        self.counts["web"] += 1

    def w_app(self, level, service, text):
        ts = self.now().isoformat(timespec="milliseconds")
        self.app.write(f"{ts} {level:<5} [{service}] {text}\n")
        self.counts["app"] += 1

    def w_sec(self, text):
        ts = datetime.now(IST).strftime("%b %d %H:%M:%S")
        self.sec.write(f"{ts} bastion01 {text}\n")
        self.counts["secure"] += 1

    # ---- behaviours -------------------------------------------------
    def browse(self):
        ip, ua = rip(), random.choice(UAS)
        p = random.choice(list(PRODUCTS))
        r = random.random()
        if r < 0.25:
            self.w_web(ip, "GET", "/", 200, random.randint(3000, 9000), ua)
        elif r < 0.45:
            self.w_web(ip, "GET", f"/category.screen?category_id={CATS[p[:4]]}", 200, random.randint(3000, 9000), ua)
        elif r < 0.85:
            self.w_web(ip, "GET", f"/product.screen?product_id={p}", 200, random.randint(3000, 9000), ua)
        elif r < 0.95:
            self.w_web(ip, "POST", f"/cart.do?action=addtocart&product_id={p}", 200, random.randint(500, 1500), ua)
        else:
            self.w_web(ip, "GET", f"/search?q={random.choice(['earbuds', 'smartphone', 'kurta', 'yoga+mat'])}", 200, random.randint(2000, 6000), ua)

    def checkout(self, fail=False):
        self.order += 1
        self.txn += 1
        p = random.choice(list(PRODUCTS))
        qty = random.choice([1, 1, 1, 2])
        amount = PRODUCTS[p] * qty
        cust = f"C{random.randint(10001, 10650)}"
        region = random.choice(REGIONS)
        ip, ua = rip(), random.choice(UAS)
        if fail:
            method = random.choice(["CARD", "CARD", "NETBANKING"])
            ms = 30000 + random.randint(5, 900)
            self.w_web(ip, "POST", f"/checkout?order_id=ORD-{self.order}", 503, random.randint(300, 700), ua)
            self.w_app("ERROR", "payment-service", f"txn_id=TXN-{self.txn} Payment gateway gw-beta timed out after 30000 ms for order ORD-{self.order} attempt 3 of 3")
            self.w_app("ERROR", "order-service", f"txn_id=TXN-{self.txn} customer_id={cust} action=checkout order_id=ORD-{self.order} product_id={p} qty={qty} amount={amount:.2f} payment_method={method} status=FAILED error_code=PAY_GW_TIMEOUT response_ms={ms} region={region}")
            return
        method = random.choice(["UPI", "UPI", "CARD", "CARD", "NETBANKING", "WALLET", "COD"])
        ms = random.randint(150, 700)
        if random.random() < 0.05:
            self.w_web(ip, "POST", f"/checkout?order_id=ORD-{self.order}", 402, random.randint(400, 900), ua)
            self.w_app("WARN", "order-service", f"txn_id=TXN-{self.txn} customer_id={cust} action=checkout order_id=ORD-{self.order} product_id={p} qty={qty} amount={amount:.2f} payment_method={method} status=DECLINED error_code=PAY_DECLINED response_ms={ms} region={region}")
        else:
            self.w_web(ip, "POST", f"/checkout?order_id=ORD-{self.order}", 200, random.randint(2000, 4000), ua)
            self.w_app("INFO", "order-service", f"txn_id=TXN-{self.txn} customer_id={cust} action=checkout order_id=ORD-{self.order} product_id={p} qty={qty} amount={amount:.2f} payment_method={method} status=SUCCESS response_ms={ms} region={region}")

    def admin_login(self):
        u, src = random.choice(ADMINS)
        self.pid += random.randint(1, 30)
        self.w_sec(f"sshd[{self.pid}]: Accepted publickey for {u} from {src} port {random.randint(40000, 65000)} ssh2: RSA SHA256:LIVE{random.randint(100000, 999999)}")
        self.w_sec(f"sshd[{self.pid}]: pam_unix(sshd:session): session opened for user {u} by (uid=0)")

    def brute(self):
        u = random.choice(BF_USERS)
        self.pid += 1
        port = random.randint(30000, 65000)
        if u in ("root", "deploy", "ubuntu"):
            self.w_sec(f"sshd[{self.pid}]: Failed password for {u} from 203.0.113.99 port {port} ssh2")
        else:
            self.w_sec(f"sshd[{self.pid}]: Invalid user {u} from 203.0.113.99 port {port}")
            self.w_sec(f"sshd[{self.pid}]: Failed password for invalid user {u} from 203.0.113.99 port {port} ssh2")


def main():
    ap = argparse.ArgumentParser(description="NovaMart live traffic generator")
    ap.add_argument("--mode", nargs="+", default=["normal"], choices=["normal", "incident", "bruteforce"])
    ap.add_argument("--minutes", type=float, default=30)
    ap.add_argument("--outdir", default=os.path.dirname(os.path.abspath(__file__)))
    a = ap.parse_args()
    lv = Live(a.outdir)
    end = time.time() + a.minutes * 60
    tick = 0
    print(f"Writing {', '.join(a.mode)} traffic to {a.outdir} for {a.minutes:g} min (Ctrl+C to stop)", flush=True)
    try:
        while time.time() < end:
            tick += 1
            if "normal" in a.mode:
                for _ in range(random.randint(1, 3)):
                    lv.browse()
                if random.random() < 0.12:
                    lv.checkout()
                if tick % 60 == 0:
                    lv.w_app("INFO", "platform", f"Heartbeat OK services=5 jvm_heap_used_pct={random.randint(38, 71)}")
                if random.random() < 0.01:
                    lv.admin_login()
            if "incident" in a.mode:
                if tick % 7 == 0:
                    lv.checkout(fail=True)
                if tick % 60 == 1:
                    lv.w_app("WARN", "payment-service", f"Circuit breaker HALF_OPEN for gateway gw-beta failure_rate_pct={random.randint(78, 93)}")
            if "bruteforce" in a.mode and tick % 2 == 0:
                lv.brute()
            if tick % 30 == 0:
                print(f"  {datetime.now():%H:%M:%S}  events written: {lv.counts}", flush=True)
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    print(f"Done. Events written: {lv.counts}")


if __name__ == "__main__":
    main()
